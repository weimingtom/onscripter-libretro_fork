#include<stdio.h>
main(){int ch; while ((ch = getchar()) != EOF) putchar(ch ^ 0x84);}

