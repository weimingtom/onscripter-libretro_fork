#!/bin/sh
#echo "===================================="
echo $0 $*

RA_DIR=/mnt/SDCARD/RetroArch
EMU_DIR=/mnt/SDCARD/Emus/ONS

cd $RA_DIR/

$EMU_DIR/cpufreq.sh
$EMU_DIR/cpuswitch.sh
$EMU_DIR/conf_script.sh "$1" "$(basename "$0")"

#disable netplay
NET_PARAM=

HOME=$RA_DIR/ $RA_DIR/ra64.trimui -v $NET_PARAM -L $RA_DIR/.retroarch/cores/onscripter_libretro_jh_aarch64.so "$*"
