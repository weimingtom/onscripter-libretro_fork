#!/bin/sh
# 获取脚本所在文件夹名称
folder_name=$(basename "$(dirname "$(readlink -f "$0")")")
# 游戏名称
tmpgame_name=$(basename "$1")
# 游戏名称去后缀
# game_name="${tmpgame_name%.*}"
# 配置文件路径
conf="/mnt/SDCARD/Conf"

# 使用第一个参数作为游戏文件路径
game_path="$1"
# 获取游戏文件上一级文件夹名称
game_abs_path=$(readlink -f "$game_path")
# 获取上一级文件夹名称
game_parent_name=$(basename "$(dirname "$game_abs_path")")

# 拼接配置文件路径
config_path="$conf/$folder_name/$game_parent_name/$tmpgame_name.conf"
# 自动创建配置文件路径
mkdir -p "$(dirname "$config_path")"
touch "$config_path"

# 将内容写入到目标脚本
cat > $config_path << EOF
$2
EOF