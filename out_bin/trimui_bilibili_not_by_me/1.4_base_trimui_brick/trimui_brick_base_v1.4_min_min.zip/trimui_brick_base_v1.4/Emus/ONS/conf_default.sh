#!/bin/sh
launch='launch.sh'
# echo $0 $*
# log_file="/mnt/SDCARD/Emus/ONS/run2.log"
progdir=`dirname "$0"`

# 获取脚本所在文件夹名称
folder_name=$(basename "$(dirname "$(readlink -f "$0")")")
# 游戏名称
tmpgame_name=$(basename "$*")
# 游戏名称去后缀
# game_name="${tmpgame_name%.*}"
# 配置文件路径
conf="/mnt/SDCARD/Conf"

# 使用第一个参数作为游戏文件路径
game_path="$1"
# 获取游戏文件上一级文件夹名称
game_abs_path=$(readlink -f "$game_path")
# 获取上一级文件夹名称
game_parent_name=$(basename "$(dirname "$game_abs_path")")

# 拼接配置文件路径
config_path="$conf/$folder_name/$game_parent_name/$tmpgame_name.conf"

# 检查文件是否存在
if [ -f "$config_path" ]; then
    config_content=$(cat "$config_path")
    # echo "$config_content" > "$log_file" 2>&1

    # 检查内容是否为空或不是.sh后缀
    if [ ! -f "$progdir/$config_content" ] || [ -z "$config_content" ] || [[ ! "$config_content" =~ \.sh$ ]]; then
        # echo "配置文件内容无效: '$config_content'" > "$log_file" 2>&1
        config_content=$launch
    fi
else
    # echo "配置文件不存在: $config_path" > "$log_file" 2>&1
    config_content=$launch
fi

# 启动游戏脚本
"$progdir/$config_content" "$*"

