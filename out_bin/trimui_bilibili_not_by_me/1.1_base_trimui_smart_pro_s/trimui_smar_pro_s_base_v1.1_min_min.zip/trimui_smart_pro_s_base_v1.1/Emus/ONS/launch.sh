#!/bin/sh
echo $0 $*
mydir=`dirname "$0"`
gamedir=`dirname "$1"`
EMU_DIR=/mnt/SDCARD/Emus/ONS

log_file="/mnt/SDCARD/Emus/ONS/run2.log"

echo 1 > /sys/class/drm/card0-DSI-1/rotate
echo 1 > /sys/class/drm/card0-DSI-1/force_rotate

export HOME=$gamedir
export PATH=$mydir:$PATH
export LD_LIBRARY_PATH=$mydir/lib:$LD_LIBRARY_PATH

$EMU_DIR/cpufreq.sh
$EMU_DIR/cpuswitch.sh
$EMU_DIR/conf_script.sh "$1" "$(basename "$0")"

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

controlfolder="/roms/ports/PortMaster"
source $controlfolder/control.txt

$GPTOKEYB "onscripter" &
cd $gamedir
onscripter > "$log_file" 2>&1



