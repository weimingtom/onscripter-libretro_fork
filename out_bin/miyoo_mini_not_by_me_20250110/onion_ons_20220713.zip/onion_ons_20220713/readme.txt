/home/steward/Data/mmiyoo/ons
https://github.com/steward-fu/website/releases?q=miyoo&expanded=true

---

二合一版（0419新固件）V3.10.5 只有ONS游戏懒人包32G
小白系统二合一（0419新固件）V3.10.5 by FISH

小白系统二合一版V3.10.5

链接：https://pan.baidu.com/s/1XNygb0ID9rU_gwJQgs57UA 
提取码：7v52 
分机种游戏包（图片需自己移动到对应游戏目录的Imgs下）
链接：https://pan.baidu.com/s/1K00xP7BI5yXgzr3OKKYhtg 
提取码：o4o2

此版本仅用于更新了官方0419固件的机器，未更新的请不要使用。

整合了洋葱V3.10.5版本和小白官方系统V2，两个系统可通过软件应用里的程序进行切换。

洋葱3.10.5版本新特性：
支持模拟器声音修正，支持界面电量百分比显示，增加洞窟物语模拟器

两个系统都已开启声音修正，针对不支持声音修正的游戏做了无缝切换处理，无需在系统菜单进行设置。

更新了开机画面和充电画面（官方系统的由路人甲友情提供）

安装方法：
全新安装：将整合包文件解压（解压密码：miyoo），并把所有文件复制到空卡
升级安装：首先将卡里的RetroArch/.retroarch/saves和RetroArch/.retroarch/states两个目录备份到电脑，保留Roms、VIDEO、PDF等数据目录，删除其它的文件及目录，将整合包文件解压，并把所有文件复制到卡里，复制完成后，将之前的备份复制到卡的Saves\CurrentProfile目录下。

快捷键说明
官方系统模拟器：
menu打开菜单，L2键为辅助连发键，R2为加速切换键

洋葱系统专用
Power		- 系统界面为关机，游戏中为退出游戏存盘并关机
Menu短按		- 退出游戏 
Menu+Power	- 待机（游戏会暂停并关屏，再次按Power恢复）

Onion系统、官方系统RA模拟器快捷键统一如下：
Menu+L2 - 载入即时存档
Menu+R2 -  保存即时存档
Menu+L - 回溯
Menu+R - 加速开关
Menu+A - 暂停
Menu+X - 显示帧数
Menu+Select - 快捷菜单
Menu+Start - 退出游戏
Select+L2/R2 - 洋葱系统调节亮度
Start+L2/R2 - 官方系统调节亮度


                              FISH 22.5.17
