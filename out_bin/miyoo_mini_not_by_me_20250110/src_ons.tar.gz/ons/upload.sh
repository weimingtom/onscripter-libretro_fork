#!/bin/sh
scp onscripter sardec nsadec sarconv nsaconv root@192.168.2.243:/emuelec/bin/