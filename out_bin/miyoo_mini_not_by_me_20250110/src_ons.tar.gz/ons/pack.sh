#!/bin/bash
tar -czvf ons-bin-1.1.tar.gz onscripter sardec nsadec sarconv nsaconv