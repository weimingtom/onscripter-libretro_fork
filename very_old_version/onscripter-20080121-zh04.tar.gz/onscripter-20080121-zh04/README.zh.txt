To compile zh version, you MUST define CHARSET variable while calling make.

# make -f Makefile.mingw32 CHARSET=gbk

Valid values of CHARSET are "gbk", "big5" or "shift-jis".


For PSP, you may additionally set PSP_FW_VERSION variable to specify firmware
version. Default firmware version is 371.

# make -f Makefile.PSP CHARSET=gbk PSP_FW_VERSION=371
