These icons are from the "Humanity" Gnome theme.
License: GPL

