DinguxCommander

author , source: https://github.com/od-contrib/commander

compile , adapted to Trimui smart Pro by 寒宇.改

tested by 铁炮玉 

8:34 2024/2/2