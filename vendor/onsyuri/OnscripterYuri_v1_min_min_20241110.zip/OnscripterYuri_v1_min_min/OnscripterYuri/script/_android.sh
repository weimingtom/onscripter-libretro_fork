# must use after _fetch.sh from cross_android.sh
# not used now as it directly build by android studio